package com.cep.rest.TaskProcessService;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.Map;
import java.util.Properties;

import org.apache.spark.SparkConf;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MappingJsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import com.fasterxml.uuid.Generators;

@Service
@Scope(value = "prototype", proxyMode = ScopedProxyMode.TARGET_CLASS)

public class TaskService implements TaskServiceInterface {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private void saveToDatabase(ArrayNode node, String tableName, SparkSession spark) {
		try {

			System.out.println("reading now");

			ObjectMapper outputMapper = new ObjectMapper();

			String arrayToJson = outputMapper.writeValueAsString(node);
			File file = File.createTempFile("temp", ".json");
			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			bw.write(arrayToJson);
			bw.close();

			Dataset<Row> dfJSON = spark.read().json(file.getAbsolutePath());
			 dfJSON.show();
			System.out.println("writing data to DB");
			Properties connectionProperties = new Properties();
			connectionProperties.put("user", "DATASOURCE_USERNAME");
			connectionProperties.put("password", "DATASOURCE_PASSWORD");
			connectionProperties.put("Driver", "org.postgresql.Driver");
			dfJSON.write().mode(SaveMode.Append).jdbc("DATASOURCE_URL", tableName, connectionProperties);

			// Delete file on exit
			file.delete();
			// spark.stop();
		} catch (Exception e) {
			if (spark != null) {
				spark.stop();
				spark.close();
			}
			logger.error("Error [" + e.getMessage() + "] occurred in Inside TaskService class - saveToDatabase method");
			System.out.println(e.getMessage());
			e.printStackTrace(System.out);
		}
	}

	private SparkSession createSparkConnection() {
		SparkSession spark = null;
		try {
			System.out.println("CREATING SPARK SESSION");
			File workaround = new File(".");
			System.getProperties().put("hadoop.home.dir", workaround.getAbsolutePath());
			new File("./bin").mkdirs();
			new File("./bin/winutils.exe").createNewFile();

			// spark = SparkSession.builder().appName("Java Spark SQL data
			// sources").master("local").getOrCreate();

			SparkConf conf = new SparkConf().setMaster("local[*]").setAppName("Local RESTWS ML").set("spark.ui.port",
					"4041");

			spark = SparkSession.builder().config(conf)
					// .appName("Test Environment")
					// .master("local")
					.getOrCreate();

		} catch (Exception e) {
			if (spark != null) {
				spark.stop();
				spark.close();
			}
			logger.error("Error [" + e.getMessage()
					+ "] occurred in Inside TaskService class - createSparkConnection method");
			System.out.println(e.getMessage());
			e.printStackTrace(System.out);
		}
		return spark;
	}

	private void closeSparkConnection(SparkSession spark) {
		try {
			System.out.println("CLOSING SPARK SESSION");
			spark.stop();
			spark.close();
		} catch (Exception e) {
			logger.error("Error [" + e.getMessage()
					+ "] occurred in Inside TaskService class - closeSparkConnection method");
			System.out.println(e.getMessage());
			e.printStackTrace(System.out);
		}

	}

	public void tester() {
		SparkSession spark =null;
		try {
			ObjectMapper outputMapper = new ObjectMapper();
			ArrayNode arrayNode = outputMapper.createArrayNode();

			String json = "{ \"Name\" : \"57342\",\r\n" + "    \"value\" : \"15328\",\r\n"
					+ "    \"Id\" : \"DET-18\",\r\n" + "    \"Code\" : \"61444\",\r\n"
					+ "    \"UUID1\" : \"e3e475f6-feef-11e9-8210-cddac34850ab\",\r\n"
					+ "    \"UUID2\" : \"d05ff892-feef-11e9-8210-91f4f95312e5\",\r\n"
					+ "    \"UUID3\" : \"e3e44ee0-feef-11e9-8210-4dc173e409ac\",\r\n"
					+ "    \"UUID4\" : \"d07b492a-feef-11e9-8210-03f87752db12\"\r\n" + "  }";
			JsonNode jsonNode = outputMapper.readTree(json);
			// outputJSON.set("DLV", jsonNode);
			arrayNode.add(jsonNode);

			json = "{ \"Name\" : \"17344\",\r\n" + "    \"value\" : \"15328\",\r\n" + "    \"Id\" : \"DET33-18\",\r\n"
					+ "    \"Code\" : \"61444\",\r\n" + "    \"UUID1\" : \"e3e475f6-feef-11e9-8210-cddac34850ab\",\r\n"
					+ "    \"UUID2\" : \"d05ff892-feef-11e9-8210-91f4f95312e5\",\r\n"
					+ "    \"UUID3\" : \"e3e44ee0-feef-11e9-8210-4dc173e409ac\",\r\n"
					+ "    \"UUID4\" : \"d07b492a-feef-11e9-8210-03f87752db12\"\r\n" + "  }";
			jsonNode = outputMapper.readTree(json);

			arrayNode.add(jsonNode);
			spark = this.createSparkConnection();
			this.saveToDatabase(arrayNode, "tableName", spark);
			this.closeSparkConnection(spark);

		} catch (Exception e) {
			logger.warn("Error in the process");
			System.out.println(e.getMessage());
			e.printStackTrace(System.out);
		}finally{
			if (spark != null) {
				spark.stop();
				spark.close();
			}
		}
	}

}
