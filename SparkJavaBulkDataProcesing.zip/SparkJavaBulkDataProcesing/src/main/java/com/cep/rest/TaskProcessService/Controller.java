package com.cep.rest.TaskProcessService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;


@RestController
public class Controller {
	
	@Autowired
	private TaskServiceInterface taskService;
	
	@RequestMapping(value="/tester", method = RequestMethod.POST)
	public void tester(@RequestBody String name) {
		try {
	
		taskService.tester();
		}
		catch (Exception e){
			System.out.println(e);
		}
	}
	
	
}
