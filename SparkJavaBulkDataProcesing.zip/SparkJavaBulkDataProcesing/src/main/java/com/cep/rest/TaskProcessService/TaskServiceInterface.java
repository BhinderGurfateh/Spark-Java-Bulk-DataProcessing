package com.cep.rest.TaskProcessService;

public interface TaskServiceInterface {
	
	void tester();
}
